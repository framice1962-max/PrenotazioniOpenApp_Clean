
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label

class Root(BoxLayout):
    pass

class PrenotazioniOpenApp(App):
    title = "PrenotazioniOpenApp"
    def build(self):
        box = BoxLayout(orientation='vertical', padding=20, spacing=10)
        box.add_widget(Label(text='Prenotazioni Open App', font_size='24sp'))
        box.add_widget(Label(text='Build di test — API 33, Build-Tools 34.0.0', font_size='16sp'))
        return box

if __name__ == '__main__':
    PrenotazioniOpenApp().run()
