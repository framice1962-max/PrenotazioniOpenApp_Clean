
# PrenotazioniOpenApp — Clean Starter

Starter minimale Kivy per validare la pipeline Android: API 33 + Build-Tools 34.0.0.

## Struttura
- `main.py` — App Kivy minima.
- `buildozer.spec` — **pinned** a `android.api=33`, `android.build_tools_version=34.0.0`, `android.accept_sdk_license=True`.
- `assets/icon.png` — icona placeholder.

## Note
Questo pacchetto è pensato per essere zippato alla radice senza cartella wrapper.

