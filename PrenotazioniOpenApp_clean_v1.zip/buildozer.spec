
[app]
title = PrenotazioniOpenApp
package.name = prenotazioni_open_app
package.domain = org.open
source.dir = .
source.include_exts = py,kv,png,ttf,db,sql,csv,md
version = 0.3.0
requirements = python3,kivy
orientation = portrait
fullscreen = 0
icon.filename = assets/icon.png
android.archs = armeabi-v7a, arm64-v8a
android.api = 33
android.minapi = 21
android.permissions = WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE
android.build_tools_version = 34.0.0
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1
